// foo.ts
