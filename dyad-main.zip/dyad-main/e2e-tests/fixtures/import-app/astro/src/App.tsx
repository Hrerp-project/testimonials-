const App = () => <div>Minimal imported app</div>;

export default App;
