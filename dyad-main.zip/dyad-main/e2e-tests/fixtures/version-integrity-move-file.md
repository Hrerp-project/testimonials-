Moving a file
<dyad-rename from="dir/c.txt" to="new-dir/d.txt"></dyad-rename>
