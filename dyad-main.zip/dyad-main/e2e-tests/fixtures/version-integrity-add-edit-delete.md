Deleting a file

<dyad-delete path="to-be-deleted.txt"></dyad-delete>
<dyad-write path="new-file.js" description="new file">
new-file
end of new-file
</dyad-write>
<dyad-write path="to-be-edited.txt" description="editing file">
after-edit
</dyad-write>
