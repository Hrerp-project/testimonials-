ALTER TABLE `apps` ADD `vercel_project_id` text;--> statement-breakpoint
ALTER TABLE `apps` ADD `vercel_project_name` text;--> statement-breakpoint
ALTER TABLE `apps` ADD `vercel_team_id` text;--> statement-breakpoint
ALTER TABLE `apps` ADD `vercel_deployment_url` text;